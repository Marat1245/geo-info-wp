<div class="notification">
    <span>Ссылка скопирована</span>
    <img src="<?php echo get_template_directory_uri(); ?>/img/icons/close_20.svg" alt="">
</div>