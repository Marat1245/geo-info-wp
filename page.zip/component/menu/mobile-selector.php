<div class="mobile_selector_wrap">
    <div class="mobile_selector">
        <div class="selector_first">
            <ul>
                <li data-li="share">
                    <div><img src="<?php echo get_template_directory_uri(); ?>/img/icons/share_20.svg" alt="">Поделиться</div>
                    <img src="<?php echo get_template_directory_uri(); ?>/img/icons/arrow_right_20.svg" alt="">
                </li>
                <!-- Остальные пункты -->
            </ul>
        </div>
        <div class="selector_second">
            <div class="back_list"><img src="<?php echo get_template_directory_uri(); ?>/img/icons/arrow_left_20.svg" alt="">Поделиться<span class="back_list_empty"></span></div>
            <ul>
                <li data-li="link"><img src="<?php echo get_template_directory_uri(); ?>/img/icons/link_20.svg" alt="">Скопировать ссылку</li>
                <!-- Остальные пункты -->
            </ul>
        </div>
    </div>
</div>
<div class="bg_dark_mobile_selector"></div>