<div class="sponsor">
    <span class="sponsor_title">Генеральные спонсоры проекта</span>
    <div class="sponsor_img_wrap">
        <a href="#"><img class="sponsor_img link_company" src="<?php echo get_template_directory_uri(); ?>/img/sponsors/sponsor_01.png" alt=""></a>
        <a href="#"><img class="sponsor_img link_company" src="<?php echo get_template_directory_uri(); ?>/img/sponsors/sponsor_02.png" alt=""></a>
        <a href="#"><img class="sponsor_img link_company" src="<?php echo get_template_directory_uri(); ?>/img/sponsors/sponsor_03.png" alt=""></a>
        <a href="#"><img class="sponsor_img link_company" src="<?php echo get_template_directory_uri(); ?>/img/sponsors/sponsor_08.png" alt=""></a>
        <a href="#"><img class="sponsor_img link_company" src="<?php echo get_template_directory_uri(); ?>/img/sponsors/sponsor_05.png" alt=""></a>
        <a href="#"><img class="sponsor_img link_company" src="<?php echo get_template_directory_uri(); ?>/img/sponsors/sponsor_06.png" alt=""></a>
        <a href="#"><img class="sponsor_img link_company" src="<?php echo get_template_directory_uri(); ?>/img/sponsors/sponsor_07.png" alt=""></a>
    </div>
    <span class="sponsor_title">Спонсоры проекта</span>
    <div class="sponsor_img_wrap">
        <a href="#"><img class="sponsor_img link_company" src="<?php echo get_template_directory_uri(); ?>/img/sponsors/sponsor_01.png" alt=""></a>
        <a href="#"><img class="sponsor_img link_company" src="<?php echo get_template_directory_uri(); ?>/img/sponsors/sponsor_02.png" alt=""></a>
        <a href="#"><img class="sponsor_img link_company" src="<?php echo get_template_directory_uri(); ?>/img/sponsors/sponsor_03.png" alt=""></a>
        <a href="#"><img class="sponsor_img link_company" src="<?php echo get_template_directory_uri(); ?>/img/sponsors/sponsor_08.png" alt=""></a>
    </div>
</div>