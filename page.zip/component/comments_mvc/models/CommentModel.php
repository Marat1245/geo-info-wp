<?php
class CommentModel {
    private $wpdb;
    private $like_model;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->like_model = new CommentLikeModel();
    }

    public function get_comments_count($post_id) {
        return get_comments(array(
            'post_id' => $post_id,
            'count' => true
        ));
    }

    public function get_comments($post_id, $page = 1, $per_page = 5) {
        $offset = ($page - 1) * $per_page;
        
        $comments = get_comments(array(
            'post_id' => $post_id,
            'number' => $per_page,
            'offset' => $offset,
            'order' => 'DESC',
            'orderby' => 'comment_date'
        ));

        $total_comments = $this->get_comments_count($post_id);
        $total_pages = ceil($total_comments / $per_page);

        $formatted_comments = array();
        foreach ($comments as $comment) {
            $formatted_comments[] = array(
                'id' => $comment->comment_ID,
                'content' => $comment->comment_content,
                'author' => $comment->comment_author,
                'date' => $comment->comment_date,
                'likes_count' => $this->like_model->get_likes_count($comment->comment_ID)
            );
        }

        return array(
            'comments' => $formatted_comments,
            'has_more' => $page < $total_pages,
            'remaining' => $total_comments - ($page * $per_page)
        );
    }

    public function add_comment($post_id, $author, $content) {
        $comment_data = array(
            'comment_post_ID' => $post_id,
            'comment_author' => $author,
            'comment_content' => $content,
            'comment_approved' => 1,
            'comment_date' => current_time('mysql'),
        );

        return wp_insert_comment($comment_data);
    }

    public function update_comment($comment_id, $content) {
        $comment = get_comment($comment_id);
        if (!$comment) {
            return false;
        }
        
        $comment->comment_content = $content;
        return wp_update_comment((array) $comment);
    }

    public function delete_comment($comment_id) {
        $comment = get_comment($comment_id);
        if (!$comment) {
            return false;
        }
        
        $comment->comment_approved = 'trash';
        return wp_update_comment((array) $comment);
    }

    public function restore_comment($comment_id) {
        $comment = get_comment($comment_id);
        if (!$comment) {
            return false;
        }
        
        $comment->comment_approved = 1;
        return wp_update_comment((array) $comment);
    }
} 