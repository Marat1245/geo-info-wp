<?php
class CommentLikeModel {
    private $wpdb;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
    }

    public function get_likes_count($comment_id) {
        return (int) $this->wpdb->get_var($this->wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->wpdb->prefix}comment_likes WHERE comment_id = %d",
            $comment_id
        ));
    }

    public function is_liked_by_user($comment_id, $user_id) {
        return (bool) $this->wpdb->get_var($this->wpdb->prepare(
            "SELECT COUNT(*) FROM {$this->wpdb->prefix}comment_likes WHERE comment_id = %d AND user_id = %d",
            $comment_id,
            $user_id
        ));
    }

    public function get_likes_status($comment_ids, $user_id) {
        if (empty($comment_ids)) {
            return array();
        }

        $placeholders = implode(',', array_fill(0, count($comment_ids), '%d'));
        $query = $this->wpdb->prepare(
            "SELECT comment_id FROM {$this->wpdb->prefix}comment_likes 
            WHERE comment_id IN ($placeholders) AND user_id = %d",
            array_merge($comment_ids, array($user_id))
        );

        return $this->wpdb->get_col($query);
    }

    public function toggle_like($comment_id, $user_id) {
        if ($this->is_liked_by_user($comment_id, $user_id)) {
            $this->wpdb->delete(
                $this->wpdb->prefix . 'comment_likes',
                array(
                    'comment_id' => $comment_id,
                    'user_id' => $user_id
                ),
                array('%d', '%d')
            );
            return false;
        } else {
            $this->wpdb->insert(
                $this->wpdb->prefix . 'comment_likes',
                array(
                    'comment_id' => $comment_id,
                    'user_id' => $user_id
                ),
                array('%d', '%d')
            );
            return true;
        }
    }
} 