<?php
class CommentController {
    private $model;
    
    public function __construct() {
        $this->model = new CommentModel();
    }

    public function handle_comment_submission() {
        if (!isset($_POST['comment_content']) || !isset($_POST['post_id']) || !isset($_POST['author'])) {
            wp_send_json_error(['message' => 'Не все необходимые данные предоставлены']);
            return;
        }

        $post_id = intval($_POST['post_id']);
        $author = sanitize_text_field($_POST['author']);
        $content = wp_kses_post($_POST['comment_content']);

        if (empty($content)) {
            wp_send_json_error(['message' => 'Комментарий не может быть пустым']);
            return;
        }

        $comment_id = $this->model->add_comment($post_id, $author, $content);
        
        if ($comment_id) {
            $comment = $this->model->get_comments($post_id, 1, 1);
            wp_send_json_success([
                'message' => 'Комментарий добавлен!',
                'comment' => $comment['comments'][0]
            ]);
        } else {
            wp_send_json_error(['message' => 'Ошибка при добавлении комментария']);
        }
    }

    public function handle_comment_update() {
        if (!isset($_POST['comment_id']) || !isset($_POST['new_content'])) {
            wp_send_json_error(['message' => 'Не все необходимые данные предоставлены']);
            return;
        }

        $comment_id = intval($_POST['comment_id']);
        $new_content = wp_kses_post($_POST['new_content']);

        if (empty($new_content)) {
            wp_send_json_error(['message' => 'Комментарий не может быть пустым']);
            return;
        }

        $updated = $this->model->update_comment($comment_id, $new_content);
        
        if ($updated) {
            wp_send_json_success(['message' => 'Комментарий обновлен!']);
        } else {
            wp_send_json_error(['message' => 'Ошибка при обновлении']);
        }
    }

    public function handle_comment_delete() {
        if (!isset($_POST['comment_id'])) {
            wp_send_json_error(['message' => 'ID комментария не указан']);
            return;
        }

        $comment_id = intval($_POST['comment_id']);
        $deleted = $this->model->delete_comment($comment_id);
        
        if ($deleted) {
            wp_send_json_success(['message' => 'Комментарий удален!']);
        } else {
            wp_send_json_error(['message' => 'Ошибка при удалении']);
        }
    }

    public function handle_comment_restore() {
        if (!isset($_POST['comment_id'])) {
            wp_send_json_error(['message' => 'ID комментария не указан']);
            return;
        }

        if (!check_ajax_referer('comment_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => 'Ошибка безопасности']);
            return;
        }

        $comment_id = intval($_POST['comment_id']);
        $restored = $this->model->restore_comment($comment_id);
        
        if ($restored) {
            wp_send_json_success(['message' => 'Комментарий восстановлен!']);
        } else {
            wp_send_json_error(['message' => 'Ошибка при восстановлении комментария']);
        }
    }

    public function load_more_comments() {
        if (!isset($_POST['post_id']) || !isset($_POST['page'])) {
            wp_send_json_error(['message' => 'Не все необходимые данные предоставлены']);
            return;
        }

        $post_id = intval($_POST['post_id']);
        $page = intval($_POST['page']);
        
        $comments = $this->model->get_comments($post_id, $page);
        wp_send_json_success($comments);
    }
} 