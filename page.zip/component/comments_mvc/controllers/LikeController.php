<?php
class CommentLikeController {
    private $model;
    
    public function __construct() {
        $this->model = new CommentLikeModel();
    }

    public function handle_like_toggle() {
        check_ajax_referer('comment_nonce', 'nonce');
        
        if (!is_user_logged_in()) {
            wp_send_json_error('Пользователь не авторизован');
            return;
        }
        
        $comment_id = intval($_POST['comment_id']);
        $user_id = get_current_user_id();
        
        $is_liked = $this->model->toggle_like($comment_id, $user_id);
        $likes_count = $this->model->get_likes_count($comment_id);
        
        wp_send_json_success(array(
            'is_liked' => $is_liked,
            'likes_count' => $likes_count
        ));
    }
} 