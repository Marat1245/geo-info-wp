jQuery(document).ready(function ($) {
    // Добавление комментария
    $('.comment_input_wrap').on('submit', function (e) {
        e.preventDefault();
        const $form = $(this);
        const content = $form.find('.comment_input').text();
        const postId = $form.find('input[name="post_id"]').val();
        const author = $form.find('input[name="author"]').val();

        $.ajax({
            url: commentsMVC.ajaxurl,
            type: 'POST',
            data: {
                action: 'add_comment',
                comment_content: content,
                post_id: postId,
                author: author
            },
            success: function (response) {
                if (response.success) {
                    $form.find('.comment_input').empty();
                    // Добавляем новый комментарий в начало списка
                    const $commentsList = $form.closest('.comment_block').find('.comments_list');
                    const $newComment = $(response.data.comment);
                    $commentsList.prepend($newComment);
                } else {
                    alert(response.data.message);
                }
            }
        });
    });

    // Загрузка дополнительных комментариев
    $('#load-more-comments').on('click', function () {
        const $button = $(this);
        const $commentsList = $button.closest('.comment_block').find('.comments_list');
        const postId = $button.closest('.comment_block').data('post-id');
        const currentPage = parseInt($button.data('page') || 1) + 1;

        $.ajax({
            url: commentsMVC.ajaxurl,
            type: 'POST',
            data: {
                action: 'load_more_comments',
                post_id: postId,
                page: currentPage
            },
            success: function (response) {
                if (response.success) {
                    const comments = response.data.comments;
                    comments.forEach(function (comment) {
                        $commentsList.append(comment);
                    });

                    if (!response.data.has_more) {
                        $button.remove();
                    } else {
                        $button.data('page', currentPage);
                    }
                }
            }
        });
    });

    // Удаление комментария
    $(document).on('click', '.delete-comment', function () {
        const $comment = $(this).closest('.user_comment');
        const commentId = $comment.data('id');

        $.ajax({
            url: commentsMVC.ajaxurl,
            type: 'POST',
            data: {
                action: 'delete_comment',
                comment_id: commentId
            },
            success: function (response) {
                if (response.success) {
                    $comment.find('.comment_text').hide();
                    $comment.find('.delete_comment_wrap').removeClass('hidden');
                } else {
                    alert(response.data.message);
                }
            }
        });
    });

    // Восстановление комментария
    $(document).on('click', '.restore_comment', function () {
        const $comment = $(this).closest('.user_comment');
        const commentId = $comment.data('id');

        $.ajax({
            url: commentsMVC.ajaxurl,
            type: 'POST',
            data: {
                action: 'restore_comment',
                comment_id: commentId,
                nonce: commentsMVC.nonce
            },
            success: function (response) {
                if (response.success) {
                    $comment.find('.comment_text').show();
                    $comment.find('.delete_comment_wrap').addClass('hidden');
                } else {
                    alert(response.data.message);
                }
            }
        });
    });

    // Обновление комментария
    $(document).on('click', '.edit-comment', function () {
        const $comment = $(this).closest('.user_comment');
        const $commentText = $comment.find('.comment_text');
        const currentText = $commentText.text();

        $commentText.html(`
            <textarea class="edit-comment-input">${currentText}</textarea>
            <button class="save-edit">Сохранить</button>
            <button class="cancel-edit">Отмена</button>
        `);
    });

    $(document).on('click', '.save-edit', function () {
        const $comment = $(this).closest('.user_comment');
        const commentId = $comment.data('id');
        const newContent = $comment.find('.edit-comment-input').val();

        $.ajax({
            url: commentsMVC.ajaxurl,
            type: 'POST',
            data: {
                action: 'update_comment',
                comment_id: commentId,
                new_content: newContent
            },
            success: function (response) {
                if (response.success) {
                    $comment.find('.comment_text').html(newContent);
                } else {
                    alert(response.data.message);
                }
            }
        });
    });

    $(document).on('click', '.cancel-edit', function () {
        const $comment = $(this).closest('.user_comment');
        const originalText = $comment.find('.edit-comment-input').val();
        $comment.find('.comment_text').html(originalText);
    });
}); 