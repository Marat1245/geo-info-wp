jQuery(document).ready(function ($) {
    $('.comment_input').on('input', function () {
        const $input = $(this);
        const $placeholder = $input.attr('data-placeholder');
        if ($input.text().trim() === '') {
            $input.text($placeholder);
            $input.addClass('placeholder');
        } else if ($input.text() === $placeholder) {
            $input.removeClass('placeholder');
        }
    });

    $('.comment_input').on('focus', function () {
        const $input = $(this);
        if ($input.hasClass('placeholder')) {
            $input.text('');
            $input.removeClass('placeholder');
        }
    });

    $('.comment_input').on('blur', function () {
        const $input = $(this);
        if ($input.text().trim() === '') {
            $input.text($input.attr('data-placeholder'));
            $input.addClass('placeholder');
        }
    });
}); 