jQuery(document).ready(function ($) {
    $('.comment_input').each(function () {
        const $input = $(this);
        const placeholder = $input.attr('data-placeholder');
        if ($input.text().trim() === '') {
            $input.text(placeholder);
            $input.addClass('placeholder');
        }
    });
}); 