<?php
class CommentsMVC {
    private $model;
    private $view;
    private $controller;
    private $like_model;
    private $like_controller;
    
    public function __construct() {
        $this->model = new CommentModel();
        $this->view = new CommentView();
        $this->controller = new CommentController();
        $this->like_model = new CommentLikeModel();
        $this->like_controller = new CommentLikeController();
        
        $this->init_hooks();
    }
    
    private function init_hooks() {
        // AJAX обработчики для комментариев
        add_action('wp_ajax_add_comment', array($this->controller, 'handle_comment_submission'));
        add_action('wp_ajax_update_comment', array($this->controller, 'handle_comment_update'));
        add_action('wp_ajax_delete_comment', array($this->controller, 'handle_comment_delete'));
        add_action('wp_ajax_restore_comment', array($this->controller, 'handle_comment_restore'));
        add_action('wp_ajax_load_more_comments', array($this->controller, 'load_more_comments'));
        
        // AJAX обработчики для лайков
        add_action('wp_ajax_toggle_like', array($this->like_controller, 'handle_like_toggle'));
        
        // Подключение скриптов
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    public function enqueue_scripts() {
        // Основной скрипт комментариев
        wp_enqueue_script(
            'comments-mvc',
            get_template_directory_uri() . '/component/comments_mvc/assets/js/comments.js',
            array('jquery'),
            '1.0.0',
            true
        );
        
        // Скрипт для лайков
        wp_enqueue_script(
            'comments-likes',
            get_template_directory_uri() . '/component/comments_mvc/assets/js/likes.js',
            array('jquery', 'comments-mvc'),
            '1.0.0',
            true
        );
        
        // Скрипты для плейсхолдеров
        wp_enqueue_script(
            'comment-set',
            get_template_directory_uri() . '/component/comments_mvc/assets/js/comment-set.js',
            array('jquery'),
            '1.0.0',
            true
        );
        
        wp_enqueue_script(
            'comment-placeholder',
            get_template_directory_uri() . '/component/comments_mvc/assets/js/comment_placeholder.js',
            array('jquery', 'comment-set'),
            '1.0.0',
            true
        );
        
        // Добавляем данные для скриптов
        wp_add_inline_script('comments-mvc', 'var commentsMVC = ' . json_encode(array(
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('comment_nonce'),
            'messages' => array(
                'error' => 'Произошла ошибка',
                'success' => 'Успешно'
            )
        )), 'before');
    }
    
    public function render_comments_section($post_id) {
        $this->view->render_comment_form($post_id);
        $this->view->render_comments($post_id);
    }
    
    public function get_comments_count($post_id) {
        return $this->model->get_comments_count($post_id);
    }
} 