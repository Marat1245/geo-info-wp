import { manageSearch } from './manage_search.js';
$(document).ready(function () {
    manageSearch();
});