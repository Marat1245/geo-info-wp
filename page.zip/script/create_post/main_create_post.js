import { titleTextarea } from "./title_create_post.js";

$(document).ready(function () {
    // titleTextarea();
})