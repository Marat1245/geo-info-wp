export function writeSkill() {

}