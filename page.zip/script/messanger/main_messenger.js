import { messagesTextarea } from "./input_messanger.js";
import { allert_messanger } from "./allert_messanger.js";
import { mobileManageMes } from "./mobile_manage_massanger.js";

$(document).ready(function () {
    messagesTextarea();
    allert_messanger();
    mobileManageMes();

});