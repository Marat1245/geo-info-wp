<div>
    <div class="edit_image_container">
        <div class="">Загрузить изображение

        </div>
        <input class="input_for_file" type="file" accept="image/*" style="display: none;">

    </div>
    <div class="edit_image_loaded_wrap add_block_for_copy">
        <div class="edit_image_loaded">
            <img src="./img/diplom_01.png" alt="">
        </div>
        <div class="edit_image_wrap">
            <button class="small_text stroke_btn"><span>Изменить</span></button>
            <button class="small_icon stroke_btn"><img src="./img/icons/delete_20.svg" alt=""></button>
        </div>

    </div>
</div>